import time
from read_data import read_data
import upload
import configparser
def main():
    # 创建一个 ConfigParser 对象
    config = configparser.ConfigParser()
    # 读取 config.ini 文件
    config.read("config.ini", encoding='utf-8')
    # 获取配置信息
    port = config.get('Device', 'port')
    baudrate = config.get('Device', 'baudrate')
    baudrate = int(baudrate)
    monitor_id = config.get('Monitor', 'id')
    monitor_id = int(monitor_id)
    password = config.get('Monitor', 'password')
    base_url = config.get('Monitor', 'base_url')
    monitor = None
    for i in range(3):
        try:
            monitor = upload.Monitor(monitor_id, password, base_url)
            break
        except Exception as e:
            print(f"无法连接到服务器: {e}\n第{i}次重试中...")
            time.sleep(3)
    if not monitor or not monitor.token:
        print("无法连接到服务器，请检查网络连接")
        return
############ 改这下面，吧能采集到的都上传
    while True:
        try:
            wind_speed, rainfall, temperature, local_time = read_data(port, baudrate)
            if wind_speed is None or rainfall is None or temperature is None:
                print("无法获取数据")
            else:
                monitor.upload_data(collect_time=local_time, wind_speed=wind_speed, rainfall=rainfall, air_temperature=temperature)
            time.sleep(2)
        except KeyboardInterrupt:
            print(f"end")
            break
if __name__ == "__main__":
    main()